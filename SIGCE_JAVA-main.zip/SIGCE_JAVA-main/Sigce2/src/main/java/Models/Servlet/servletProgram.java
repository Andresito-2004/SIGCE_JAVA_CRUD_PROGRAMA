package Models.Servlet;

import Models.Beans.Programa;
import Models.RepositoryDAO.Crud;
import Models.RepositoryDAO.ProgramaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "Program", value = "/Program")
public class servletProgram extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Programa progVo = new Programa();
        int Option = Integer.parseInt(req.getParameter("option"));
        progVo.setName_program(req.getParameter("Name"));
        progVo.setState_program(req.getParameter("State"));
        try {
            Crud<Programa> programaVO = new ProgramaDAO(progVo);
            switch (Option){
                case 1:
                        if (programaVO.Guardar()){
                        req.setAttribute("MensajeExitoso","Se registro correctamente");
                    }else{
                    req.setAttribute("MensajeError","No se registro correctamente");
                }req.getRequestDispatcher("/JSP/Program/programAdd.jsp").forward(req,resp);
                        break;
                case 2:
                    progVo= ProgramaDAO.consultarPrograma(progVo.getName_program());
                    if (progVo != null) {
                        req.setAttribute("Result",progVo);
                        req.setAttribute("MensajeExitoso","Si esta correctamente");
                    }else {
                        req.setAttribute("MensajeErro", "No esta correctamente");
                }req.getRequestDispatcher("/JSP/Program/programList.jsp").forward(req,resp);
                    break;
            }
            }
             catch (SQLException e) {
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }


}
