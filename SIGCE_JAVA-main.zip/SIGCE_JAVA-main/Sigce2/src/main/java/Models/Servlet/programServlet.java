package Models.Servlet;

import Models.Beans.Programa;
import Models.RepositoryDAO.Crud;
import Models.RepositoryDAO.ProgramaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name="programServlet" ,urlPatterns= {"/programServlet"}, value="/programServlet")
public class programServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String ide_Pro = req.getParameter("Ide");
        String nom_Pro = req.getParameter("Name");
        String est_Pro = req.getParameter("State");
        Programa progVo = new Programa(ide_Pro, nom_Pro, est_Pro);
        try {
            ProgramaDAO progDAO = new ProgramaDAO(progVo);
//            switch (opcion) {
//                case 1:
                    if (progDAO.Guardar()) {
                        req.setAttribute("MensajeExitoso","Se registro correctamente");
                    }else {
                        req.setAttribute("MensajeError","No se registro correctamente");
                    }req.getRequestDispatcher("programAdd.jsp").forward(req,resp);
//                    break;
//                 case 2:
//                    if (progDAO.Editar()) {
//                        req.setAttribute("MensajeExitoso","Se actualizo correctamente");
//                    }else {
//                        req.setAttribute("MensajeError","No se actualizo correctamente");
//                    }req.getRequestDispatcher("programUpdate.jsp").forward(req,resp);
//                    break;
//                case 3:
//                    progVo=ProgramaDAO.consultarPrograma(ide_Pro);
//                    if (progDAO != null) {
//                        req.setAttribute("programCheck",progDAO);
//                        req.getRequestDispatcher("programUpdate.jsp").forward(req,resp);
//                    }
//                    else {
//                        req.setAttribute("MensajeError","No existe el programa");
//                        req.getRequestDispatcher("programRead.jsp").forward(req,resp);
//                    }
//                    break;
//            }
        } catch (SQLException e) {
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE, null, e);
            System.out.println(e);
        }
//Los metodos de listar no vienen al controlador
    }
}

// NEW VERY GOOD
//@WebServlet(name = "Program", value = "/Program")
//public class servletProgram extends HttpServlet {
//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//
//        Programa progVo = new Programa();
//        progVo.setName_program(req.getParameter("Name"));
//        progVo.setState_program(req.getParameter("State"));
//        try {
//            Crud<Programa> programaVO = new ProgramaDAO(progVo);
//            if (programaVO.Guardar()){
//                req.setAttribute("MensajeExitoso","Se registro correctamente");
//            }else{
//                req.setAttribute("MensajeError","No se registro correctamente");
//            }req.getRequestDispatcher("/JSP/Program/programAdd.jsp").forward(req,resp);
//        } catch (SQLException e) {
//            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE, null, e);
//        }
//    }
//
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp);
//    }
//
//
//}

