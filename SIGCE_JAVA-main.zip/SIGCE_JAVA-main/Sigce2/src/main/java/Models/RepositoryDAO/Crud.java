package Models.RepositoryDAO;

import Models.Beans.Programa;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface Crud<T> {

    public abstract boolean Guardar( ) throws SQLException;

//    boolean Guardar(T t) throws SQLException;

    public abstract boolean Editar() throws SQLException;
    List<T> listar() throws SQLException;
}
