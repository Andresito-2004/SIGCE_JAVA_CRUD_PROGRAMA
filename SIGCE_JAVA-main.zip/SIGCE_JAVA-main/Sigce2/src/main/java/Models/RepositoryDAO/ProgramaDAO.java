package Models.RepositoryDAO;

import Models.Beans.Programa;
import Models.Util.ConnectionPool;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProgramaDAO extends ConnectionPool implements Crud<Programa> {
    private Connection conn;
    private PreparedStatement stmt;
    private ResultSet rs;

    public String Identification_program, Name_program = "",State_program = "";
    public boolean operation = false;
    private String sql;

    public ProgramaDAO() {
    }

    public ProgramaDAO(Programa programaVO) throws SQLException {
        super();
        try {
            conn=ConnectionPool.getConnection();
            Identification_program=programaVO.getIdentification_program();
            Name_program=programaVO.getName_program();
            State_program= programaVO.getState_program();
        }catch (Exception e){
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
        }
    }

    @Override
    public boolean Guardar() throws SQLException {
        try {
            sql = "INSERT INTO programa VALUES(?, upper(?),upper(?));";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, Identification_program);
            stmt.setString(2, Name_program);
            stmt.setString(3, State_program);
            stmt.executeUpdate();
            operation = true;

        } catch (SQLException e) {
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                this.closeConnection();
            } catch (SQLException e) {
                Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return operation;

    }

    @Override
    public boolean Editar() throws SQLException {
        try{
            sql="UPDATE programa SET nom_Pro=upper(?), est_Pro=upper(?) WHERE ide_Pro=(?) ;;";
            stmt=conn.prepareStatement(sql);
            stmt.setString(1,Name_program);
            stmt.setString(2,State_program);
            stmt.setString(3,Identification_program);
            stmt.executeUpdate();
            operation=true;

        }catch (SQLException e){
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
        }finally {
            try {
                this.closeConnection();
            }catch (SQLException e){
                Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
            }
        }
        return operation;
    }


    public static Programa consultarPrograma(String Name) throws SQLException {
        Programa progVo = null;
        try {
            Connection conexion = ConnectionPool.getConnection();
            PreparedStatement puente= null;
            String sql = "Select * from programa where nom_Pro=upper(?)";
            puente=conexion.prepareStatement(sql);
            puente.setString(1,Name);
            //Cuando es una consulta se ejecuta un resulset y executeQuery
            ResultSet rs = puente.executeQuery();
            if (rs.next()){
                progVo= new Programa(rs.getString(1),Name,rs.getString(3));
            }
        }catch (SQLException e){
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
    }finally {
            try {
                Connection conexion = ConnectionPool.closeConnection();
            }catch (SQLException e){
                Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
            }
        }
           return progVo;
    }

    @Override
    public ArrayList<Programa> listar() throws SQLException {
        ArrayList<Programa>listaPrograma = new ArrayList<Programa>();
        try {
            conn=ConnectionPool.getConnection();
            sql="select * from programa";
            stmt=conn.prepareStatement(sql);
            rs= stmt.executeQuery();
            while (rs.next()){
                Programa progVeo = new Programa(rs.getString(1),rs.getString(2),rs.getString(3));
                listaPrograma.add(progVeo);
            }
        }catch (SQLException e){
            Logger.getLogger(ProgramaDAO.class.getName()).log(Level.SEVERE,null,e);
        }
        return listaPrograma;
    }

}

