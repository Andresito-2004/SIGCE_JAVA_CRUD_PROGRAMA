CREATE DATABASE SIGCE2;
USE SIGCE2;

CREATE TABLE PROGRAMA(
ide_Pro Int Not null Primary key auto_increment, -- Identifiacion de Programa--
nom_Pro varchar(60) not null,-- Nombre de Programa--
est_Pro VARCHAR(45) NOT NULL -- Estado de Programa--
);

CREATE TABLE FICHA(
ide_Fic Int Not null Primary key unique, -- Numero de ficha--
jor_Fic varchar(60) not null,-- Jornada de ficha--
est_Fic VARCHAR(45) NOT NULL ,-- Estado de ficha--
fecCom_Fic date not null,-- Fecha de comienzo de ficha--
fecFin_Fic date not null,-- Fecha de fin de ficha--
FK_ide_Pro Int Not null-- Foreing Key del programa que peretenece--
);


CREATE TABLE APRENDIZ(
ide_Apr Int Not null Primary key unique, -- Identificacion del aprendiz--
Tide_Apr varchar(30) not null, -- Tipo de Identificacion del aprendiz--
nom_Apr varchar(60) not null, -- Nombre del aprendiz--
ape_Apr varchar(60) not null,--  Apellido del aprendiz--
cor_Apr varchar(60) not null,-- Correo del aprendiz--
pass_Apr varchar(60) not null,-- Contraseña del aprendiz--
FK_ide_Fic int not null -- Foreing Key de la ficha que pertenece el aprendiz--
);

CREATE TABLE DOCUMENTACION(
ide_Doc Int Not null Primary key auto_increment,-- Id de la documentacion --
llamado1_Doc varchar(60) not null, --  Constancia de llamado de atencion por instructor--
llamado2_Doc varchar(60) not null,--  Constancia de llamado de atencion por Coordinacion--
llamado3_Doc varchar(60) not null
);

CREATE TABLE INSTRUCTOR(
ide_Ins Int Not null Primary key unique, -- Identificacion del instructor--
tipIde_Ins varchar(30) not null,-- Tipo de identifiacion del instructor--
nom_Ins varchar(60) not null, -- Nombre del instructor--
ape_Ins varchar(60) not null,--  Apellido del instructor--
cor_Ins varchar(60) not null, --  Correo del instructor-- 
pass_Ins VARCHAR(50) NOT NULL,--  Contraseña del instructor--
mat_Ins varchar(60) not null -- Materia que ejerce  del instructor--
);

CREATE TABLE CITACION(
id_Cit Int Not null Primary key auto_increment, --  Identificacion de la citacion--
est_Cit Varchar(40) not null,--  Estado de la citacion--
obv_Cit  Varchar(70) not null, --   de la citacion--
FK_ide_Doc Int not null,--  Identificacion del documentacion la citacion--
FK_ide_Apr Int not null, --  Identificacion del aprendiz que asiste a la citacion--
FK_ide_Ins Int not null --  Identificacion del instructi¿or que geneta la citacion--
);

CREATE TABLE CASO(
id_Cas Int Not null Primary key auto_increment, --  Identificacion del caso --
Des_Cas Varchar(100)not null, --  descargos del caso --
com_Cas Varchar(70)not null, --  compromiso del caso --
FK_id_Cit Int not null, --  Identificacion  la citacion caso --
FK_id_Tpd Int not null, --  Identificacion de la desicion tomada -- 
FK_id_Com int not null --  Identificacion del comite --
);

CREATE TABLE TIPO_DECISION(
id_Tpd Int Not null Primary key auto_increment, --  Identificacion del tipo de decision --
nom_Tpd Varchar(40)not null, -- nombre del tipo de decision --
des_Tpd Varchar(70)not null --  descripcion del tipo de decision --
);

CREATE TABLE COMITE(
id_Com Int Not null Primary key auto_increment,  --  Identificacion del comite --
fech_Com date not null, --  Fecha del comite --
hora_Com time not null,--  hora del comite --
FK_ide_Fun int not null --  Identificacion del funcionario --
);

CREATE TABLE FUNCIONARIO(
ide_Fun Int Not null Primary key unique, -- Identificacion--
tipIde_Fun varchar(30) not null, --  tipo de Identificacion del funcionario --
nom_Fun varchar(60) not null,--  nombre del funcionario --
ape_Ins varchar(60) not null,--  Apellidol funcionario --
corr_Ins varchar(30) not null, --  correo del funcionario --
pass_Ins Varchar(30) not null --  Contraseña del funcionario --
);
-- FICHA --
ALTER TABLE FICHA ADD FOREIGN KEY(FK_ide_Pro) REFERENCES PROGRAMA(ide_Pro);
-- APRENDIZ --
ALTER TABLE APRENDIZ ADD FOREIGN KEY(FK_ide_Fic) REFERENCES FICHA(ide_Fic);
-- CITACIÓN --
ALTER TABLE CITACION ADD FOREIGN KEY(FK_ide_Doc) REFERENCES DOCUMENTACION(ide_Doc);
ALTER TABLE CITACION ADD FOREIGN KEY(FK_ide_Apr) REFERENCES APRENDIZ(ide_Apr);
ALTER TABLE CITACION ADD FOREIGN KEY(FK_ide_Ins) REFERENCES INSTRUCTOR(ide_Ins);
-- CASO --
ALTER TABLE CASO ADD FOREIGN KEY(FK_id_Cit) REFERENCES CITACION(id_Cit);
ALTER TABLE CASO ADD FOREIGN KEY(FK_id_Tpd) REFERENCES TIPO_DECISION(id_Tpd);
ALTER TABLE CASO ADD FOREIGN KEY(FK_id_Com) REFERENCES COMITE(id_Com);
-- COMITE -- 
ALTER TABLE COMITE ADD FOREIGN KEY(FK_ide_Fun) REFERENCES FUNCIONARIO(ide_Fun);




INSERT INTO programa(nom_Pro,est_Pro) VALUES ('ANALISIS Y DESARROLLO DE SOFTWARE ADSO','Activo');

INSERT INTO ficha (ide_Fic, jor_Fic, fecCom_Fic, fecFin_Fic,est_Fic, FK_ide_Pro) VALUES ('2687386', 'DIURNA', '2023-01-25', '2024-06-27','Activo', '1');
INSERT INTO ficha (ide_Fic, jor_Fic, fecCom_Fic, fecFin_Fic,est_Fic, FK_ide_Pro) VALUES ('2687351', 'DIURNA', '2023-01-25', '2024-06-27', 'Activo', '1');

INSERT INTO aprendiz VALUES ('1019762470', 'CC', 'CARLOS', 'SARMIENTO', 'SARMIENTOKRLOS@GMAIL.COM', '2604', '2687351');

INSERT INTO `sigce2`.`instructor` (`ide_Ins`, `tipIde_Ins`, `nom_Ins`, `ape_Ins`, `cor_Ins`, `pass_Ins`, `mat_Ins`) VALUES ('1126704240', 'cc', 'JESSIKA', 'HERNANDEZ', 'HERNANDEZJESSIKA777@GMAIL.COM', '13005', 'SQL');

